from flask import Flask, render_template, request, redirect, url_for, session, jsonify, flash
import sqlite3
from werkzeug.security import generate_password_hash, check_password_hash
import os

app = Flask(__name__)
app.secret_key = 'logicweb_uta_secret_2026'
DATABASE = os.path.join(app.instance_path, 'logicweb.db')

os.makedirs(app.instance_path, exist_ok=True)

# ---------- DB HELPERS ----------

def get_db():
    conn = sqlite3.connect(DATABASE)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    db = get_db()
    db.executescript("""
        CREATE TABLE IF NOT EXISTS Usuario (
            IdUsuario   INTEGER PRIMARY KEY AUTOINCREMENT,
            Nombre      TEXT NOT NULL,
            Correo      TEXT NOT NULL UNIQUE,
            Contrasena  TEXT NOT NULL,
            Rol         TEXT DEFAULT 'Estudiante'
        );

        CREATE TABLE IF NOT EXISTS Tema (
            IdTema      INTEGER PRIMARY KEY AUTOINCREMENT,
            Unidad      TEXT NOT NULL,
            NombreTema  TEXT NOT NULL,
            Descripcion TEXT NOT NULL
        );

        CREATE TABLE IF NOT EXISTS Ejercicio (
            IdEjercicio       INTEGER PRIMARY KEY AUTOINCREMENT,
            IdTema            INTEGER NOT NULL,
            Titulo            TEXT NOT NULL,
            Enunciado         TEXT NOT NULL,
            Categoria         TEXT NOT NULL,
            Dificultad        TEXT NOT NULL,
            SolucionEsperada  TEXT,
            LineasPseudocodigo TEXT,
            FOREIGN KEY (IdTema) REFERENCES Tema(IdTema)
        );

        CREATE TABLE IF NOT EXISTS Intento (
            IdIntento       INTEGER PRIMARY KEY AUTOINCREMENT,
            IdUsuario       INTEGER NOT NULL,
            IdEjercicio     INTEGER NOT NULL,
            RespuestaUsuario TEXT,
            Resultado       INTEGER NOT NULL,
            FechaIntento    TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (IdUsuario) REFERENCES Usuario(IdUsuario),
            FOREIGN KEY (IdEjercicio) REFERENCES Ejercicio(IdEjercicio)
        );
    """)

    # Seed data only if empty
    if db.execute("SELECT COUNT(*) FROM Tema").fetchone()[0] == 0:
        db.executescript("""
            INSERT INTO Tema (Unidad, NombreTema, Descripcion) VALUES
            ('Unidad 1', 'Variables y Tipos de Datos',
             '<h5>¿Qué es una variable?</h5><p>Una variable es un espacio en memoria con un nombre que almacena un dato que puede cambiar durante la ejecución.</p><h5>Tipos de datos fundamentales</h5><ul><li><strong>Entero (int):</strong> números sin decimales. Ej: <code>edad = 20</code></li><li><strong>Real (float):</strong> números con decimales. Ej: <code>promedio = 8.5</code></li><li><strong>Cadena (str):</strong> texto. Ej: <code>nombre = "Ana"</code></li><li><strong>Booleano (bool):</strong> verdadero o falso. Ej: <code>activo = True</code></li></ul><h5>Ejemplo en pseudocódigo</h5><pre>INICIO\n  DEFINIR edad COMO Entero\n  LEER edad\n  ESCRIBIR "Tu edad es:", edad\nFIN</pre>'),

            ('Unidad 2', 'Estructuras Condicionales',
             '<h5>¿Qué es una condicional?</h5><p>Permite que el programa tome decisiones según si una condición es verdadera o falsa.</p><h5>Estructura SI-SINO</h5><pre>SI condición ENTONCES\n  instrucciones\nSINO\n  otras instrucciones\nFIN SI</pre><h5>Ejemplo: Aprobación académica</h5><pre>SI promedio >= 7 ENTONCES\n  ESCRIBIR "Aprobado"\nSINO\n  ESCRIBIR "Reprobado"\nFIN SI</pre><p>Las condicionales son la base de la lógica de programación: permiten bifurcar el flujo según los datos.</p>'),

            ('Unidad 3', 'Ciclos e Iteraciones',
             '<h5>¿Qué es un ciclo?</h5><p>Un ciclo repite un bloque de instrucciones mientras se cumpla una condición o un número determinado de veces.</p><h5>Ciclo PARA (For)</h5><pre>PARA i DESDE 1 HASTA 5 HACER\n  ESCRIBIR i\nFIN PARA</pre><h5>Ciclo MIENTRAS (While)</h5><pre>MIENTRAS condición HACER\n  instrucciones\nFIN MIENTRAS</pre><h5>Uso práctico</h5><p>Los ciclos se usan para recorrer arreglos, acumular valores y repetir menús hasta que el usuario decida salir.</p>'),

            ('Unidad 4', 'Arreglos y Estructuras',
             '<h5>¿Qué es un arreglo?</h5><p>Un arreglo (o lista) almacena múltiples valores del mismo tipo bajo un solo nombre, accedibles por índice.</p><pre>notas = [8.0, 9.5, 7.0]\nEscribir notas[0]  // Imprime 8.0</pre><h5>Estructuras (Structs)</h5><p>Agrupan datos de distinto tipo bajo un mismo objeto:</p><pre>Estructura Estudiante:\n  nombre: Cadena\n  nota:   Real\nFin Estructura</pre><p>En Python, las estructuras se representan con clases o diccionarios.</p>');

            INSERT INTO Ejercicio (IdTema, Titulo, Enunciado, Categoria, Dificultad, SolucionEsperada, LineasPseudocodigo) VALUES
            (2, 'Calculo de Promedio y Estado',
             'Un estudiante tiene 3 notas. Calcula el promedio y determina si aprueba (>= 7) o reprueba.',
             'Condicionales', 'Básica',
             '<p>El algoritmo sigue tres pasos:</p><ol><li><strong>Entrada:</strong> Leer las tres notas del estudiante.</li><li><strong>Proceso:</strong> Sumar las notas y dividir para 3. Comparar el resultado con 7.</li><li><strong>Salida:</strong> Imprimir el estado (Aprobado / Reprobado).</li></ol><pre>promedio = (n1 + n2 + n3) / 3\nSI promedio >= 7:\n  estado = "Aprobado"\nSINO:\n  estado = "Reprobado"</pre><p><strong>Clave:</strong> La condición de aprobación es mayor o IGUAL a 7, no estrictamente mayor.</p>',
             'INICIO|LEER n1, n2, n3|promedio = (n1 + n2 + n3) / 3|SI promedio >= 7 ENTONCES|IMPRIMIR "Aprobado"|SINO|IMPRIMIR "Reprobado"|FIN SI|FIN'),

            (2, 'Calculo de Sueldo con Horas Extras',
             'Un trabajador cobra una tarifa por hora. Si trabaja más de 40 horas, las horas adicionales se pagan al doble. Calcula el sueldo total.',
             'Condicionales', 'Intermedia',
             '<p>La lógica central es una condicional compuesta:</p><ol><li><strong>Entrada:</strong> Leer horas trabajadas y tarifa por hora.</li><li><strong>Proceso:</strong> Verificar si las horas superan 40.</li><li><strong>Salida:</strong> Calcular e imprimir el sueldo.</li></ol><pre>SI horas <= 40:\n  sueldo = horas * tarifa\nSINO:\n  horas_extra = horas - 40\n  sueldo = (40 * tarifa) + (horas_extra * tarifa * 2)</pre><p><strong>Error común:</strong> Multiplicar TODAS las horas por 2 en lugar de solo las que exceden las 40.</p>',
             'INICIO|LEER horas_trabajadas, tarifa|SI horas_trabajadas <= 40 ENTONCES|sueldo = horas_trabajadas * tarifa|SINO|horas_extra = horas_trabajadas - 40|sueldo = (40 * tarifa) + (horas_extra * tarifa * 2)|FIN SI|IMPRIMIR "El sueldo es:", sueldo|FIN');
        """)
    db.commit()
    db.close()

init_db()

# ---------- ROUTES: MAIN ----------

@app.route('/')
def index():
    return render_template('index.html')

# ---------- ROUTES: USUARIOS ----------

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        correo = request.form['correo']
        password = request.form['password']
        db = get_db()
        user = db.execute("SELECT * FROM Usuario WHERE Correo = ?", [correo]).fetchone()
        db.close()
        if user and check_password_hash(user['Contrasena'], password):
            session['user_id'] = user['IdUsuario']
            session['user_name'] = user['Nombre']
            session['user_rol'] = user['Rol']
            return redirect(url_for('index'))
        flash('Correo o contraseña incorrectos.', 'danger')
    return render_template('login.html')

@app.route('/registro', methods=['GET', 'POST'])
def registro():
    if request.method == 'POST':
        nombre = request.form['nombre']
        correo = request.form['correo']
        password = request.form['password']
        confirm = request.form['confirm_password']
        if password != confirm:
            flash('Las contraseñas no coinciden.', 'danger')
            return render_template('registro.html')
        db = get_db()
        existe = db.execute("SELECT * FROM Usuario WHERE Correo = ?", [correo]).fetchone()
        if existe:
            flash('El correo ya está registrado.', 'warning')
            db.close()
            return render_template('registro.html')
        hashed = generate_password_hash(password)
        db.execute("INSERT INTO Usuario (Nombre, Correo, Contrasena) VALUES (?, ?, ?)", [nombre, correo, hashed])
        db.commit()
        db.close()
        flash('Registro exitoso. ¡Inicia sesión!', 'success')
        return redirect(url_for('login'))
    return render_template('registro.html')

@app.route('/logout')
def logout():
    session.clear()
    return redirect(url_for('index'))

@app.route('/historial')
def historial():
    if 'user_id' not in session:
        return redirect(url_for('login'))
    db = get_db()
    intentos = db.execute("""
        SELECT i.*, e.Titulo, e.Categoria
        FROM Intento i
        JOIN Ejercicio e ON i.IdEjercicio = e.IdEjercicio
        WHERE i.IdUsuario = ?
        ORDER BY i.FechaIntento DESC
    """, [session['user_id']]).fetchall()
    db.close()
    return render_template('historial.html', intentos=intentos)

# ---------- ROUTES: TEORIA ----------

@app.route('/teoria')
def teoria_index():
    db = get_db()
    temas = db.execute("SELECT * FROM Tema ORDER BY Unidad ASC, IdTema ASC").fetchall()
    db.close()
    return render_template('teoria_index.html', temas=temas)

@app.route('/teoria/<int:id>')
def teoria_detalle(id):
    db = get_db()
    tema = db.execute("SELECT * FROM Tema WHERE IdTema = ?", [id]).fetchone()
    db.close()
    if not tema:
        flash('Tema no encontrado.', 'warning')
        return redirect(url_for('teoria_index'))
    return render_template('teoria_detalle.html', tema=tema)

# ---------- ROUTES: RESUELTOS ----------

@app.route('/resueltos')
def resueltos_index():
    db = get_db()
    ejercicios = db.execute("""
        SELECT e.*, t.NombreTema, t.Unidad
        FROM Ejercicio e
        JOIN Tema t ON e.IdTema = t.IdTema
        ORDER BY t.Unidad ASC, e.Dificultad ASC
    """).fetchall()
    db.close()
    return render_template('resueltos_index.html', ejercicios=ejercicios)

@app.route('/resueltos/<int:id>')
def resueltos_detalle(id):
    db = get_db()
    ejercicio = db.execute("""
        SELECT e.*, t.NombreTema
        FROM Ejercicio e
        JOIN Tema t ON e.IdTema = t.IdTema
        WHERE e.IdEjercicio = ?
    """, [id]).fetchone()
    db.close()
    if not ejercicio:
        flash('Ejercicio no encontrado.', 'warning')
        return redirect(url_for('resueltos_index'))
    return render_template('resueltos_detalle.html', ejercicio=ejercicio)

# ---------- ROUTES: EJERCICIOS ----------

@app.route('/ejercicios')
def ejercicios_index():
    db = get_db()
    ejercicios = db.execute("""
        SELECT e.*, t.NombreTema
        FROM Ejercicio e
        JOIN Tema t ON e.IdTema = t.IdTema
        ORDER BY e.Dificultad ASC
    """).fetchall()
    db.close()
    return render_template('ejercicios_index.html', ejercicios=ejercicios)

@app.route('/ejercicios/practica/<int:id>')
def practica(id):
    db = get_db()
    ej = db.execute("SELECT * FROM Ejercicio WHERE IdEjercicio = ?", [id]).fetchone()
    db.close()
    if not ej:
        return redirect(url_for('ejercicios_index'))
    return render_template('practica.html', ej=ej)

@app.route('/ejercicios/procesar', methods=['POST'])
def procesar():
    data = request.form
    id_ejercicio = data.get('id_ejercicio')
    respuesta_usuario = data.get('respuesta_usuario', '').strip()
    user_id = session.get('user_id')

    es_correcto = False
    mensaje = ""
    recomendacion = ""

    if id_ejercicio == '1':
        n1 = float(data.get('n1', 0))
        n2 = float(data.get('n2', 0))
        n3 = float(data.get('n3', 0))
        promedio = (n1 + n2 + n3) / 3
        respuesta_real = "Aprobado" if promedio >= 7 else "Reprobado"
        es_correcto = respuesta_usuario.lower() == respuesta_real.lower()
        mensaje = f"El promedio real es {round(promedio, 2)} y el estado es <b>{respuesta_real}</b>. Tu respuesta fue: {respuesta_usuario}"
        recomendacion = "Comprendes bien el uso de condicionales." if es_correcto else "Revisa la condición SI promedio >= 7."

    elif id_ejercicio == '2':
        horas = float(data.get('horas', 0))
        tarifa = float(data.get('tarifa', 0))
        if horas <= 40:
            sueldo_real = horas * tarifa
        else:
            horas_extra = horas - 40
            sueldo_real = (40 * tarifa) + (horas_extra * tarifa * 2)
        es_correcto = abs(float(respuesta_usuario or 0) - sueldo_real) < 0.01
        mensaje = f"El sueldo real es <b>${sueldo_real:,.2f}</b>. Tu respuesta fue: ${respuesta_usuario}"
        recomendacion = "Excelente manejo de bifurcaciones lógicas." if es_correcto else "Recuerda: solo las horas POR ENCIMA de 40 se multiplican por el doble de la tarifa."
    else:
        return jsonify({'status': 'error', 'message': 'Ejercicio no programado.', 'recomendacion': 'Contacta al administrador.'})

    if user_id:
        db = get_db()
        db.execute("INSERT INTO Intento (IdUsuario, IdEjercicio, RespuestaUsuario, Resultado) VALUES (?, ?, ?, ?)",
                   [user_id, id_ejercicio, respuesta_usuario, int(es_correcto)])
        db.commit()
        db.close()

    return jsonify({
        'status': 'success' if es_correcto else 'error',
        'message': mensaje,
        'recomendacion': recomendacion
    })

@app.route('/ejercicios/pseudocodigo/<int:id>')
def pseudocodigo(id):
    db = get_db()
    ej = db.execute("SELECT * FROM Ejercicio WHERE IdEjercicio = ?", [id]).fetchone()
    db.close()
    if not ej:
        return redirect(url_for('ejercicios_index'))
    lineas_raw = ej['LineasPseudocodigo'] or ''
    lineas = lineas_raw.split('|') if lineas_raw.strip() else []
    import random
    random.shuffle(lineas)
    return render_template('pseudocodigo.html', ej=ej, lineas=lineas)

@app.route('/ejercicios/procesar_pseudocodigo', methods=['POST'])
def procesar_pseudocodigo():
    id_ejercicio = request.form.get('id_ejercicio')
    orden_usuario = request.form.get('orden_usuario', '').strip()
    user_id = session.get('user_id')

    ordenes_correctos = {
        '1': "INICIO|LEER n1, n2, n3|promedio = (n1 + n2 + n3) / 3|SI promedio >= 7 ENTONCES|IMPRIMIR \"Aprobado\"|SINO|IMPRIMIR \"Reprobado\"|FIN SI|FIN",
        '2': "INICIO|LEER horas_trabajadas, tarifa|SI horas_trabajadas <= 40 ENTONCES|sueldo = horas_trabajadas * tarifa|SINO|horas_extra = horas_trabajadas - 40|sueldo = (40 * tarifa) + (horas_extra * tarifa * 2)|FIN SI|IMPRIMIR \"El sueldo es:\", sueldo|FIN"
    }

    orden_correcto = ordenes_correctos.get(id_ejercicio)
    if not orden_correcto:
        return jsonify({'status': 'error', 'message': 'Este reto aún no está disponible.'})

    es_correcto = orden_usuario == orden_correcto

    mensajes = {
        True:  "¡Excelente estructura! Has respetado correctamente las fases de Entrada, Proceso y Salida.",
        False: "Hay un error en tu secuencia. Recuerda: INICIO → Leer variables → Cálculo → Condición → Resultados → FIN."
    }

    if id_ejercicio == '2' and es_correcto:
        mensajes[True] = "¡Excelente! Has estructurado perfectamente la condicional compuesta (SI-SINO) para el cálculo de horas extras."
    elif id_ejercicio == '2':
        mensajes[False] = "Recuerda: INICIO → LEER → Condición SI (≤40) → cálculo normal → SINO → cálculo extra → FIN SI → IMPRIMIR → FIN."

    if user_id:
        db = get_db()
        db.execute("INSERT INTO Intento (IdUsuario, IdEjercicio, RespuestaUsuario, Resultado) VALUES (?, ?, ?, ?)",
                   [user_id, id_ejercicio, f"Pseudocodigo Ej{id_ejercicio}", int(es_correcto)])
        db.commit()
        db.close()

    return jsonify({
        'status': 'success' if es_correcto else 'error',
        'message': mensajes[es_correcto]
    })

if __name__ == '__main__':
    app.run(debug=True, port=5000)
